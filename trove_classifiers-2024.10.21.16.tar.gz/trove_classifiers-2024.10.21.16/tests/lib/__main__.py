from tests.lib import trove_tester
from trove_classifiers import classifiers, deprecated_classifiers

trove_tester(classifiers, deprecated_classifiers)
