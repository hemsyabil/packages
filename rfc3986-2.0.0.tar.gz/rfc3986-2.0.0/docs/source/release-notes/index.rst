===========================
 Release Notes and History
===========================

All of the release notes that have been recorded for |rfc3986| are organized
here with the newest releases first.

2.x Release Series
==================

.. toctree::

    unreleased
    2.0.0

1.x Release Series
==================

.. toctree::

    1.5.0
    1.4.0
    1.3.2
    1.3.1
    1.3.0
    1.2.0
    1.1.0
    1.0.0

0.x Release Series
==================

.. toctree::

    0.4.2
    0.4.1
    0.4.0
    0.3.1
    0.3.0
    0.2.2
    0.2.1
    0.2.0
    0.1.0
