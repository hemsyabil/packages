===============
 IRI Submodule
===============

.. autoclass:: rfc3986.iri.IRIReference

.. automethod:: rfc3986.iri.IRIReference.encode

.. automethod:: rfc3986.iri.IRIReference.from_string

.. automethod:: rfc3986.iri.IRIReference.unsplit

.. automethod:: rfc3986.iri.IRIReference.resolve_with

.. automethod:: rfc3986.iri.IRIReference.copy_with

.. automethod:: rfc3986.iri.IRIReference.is_absolute

.. automethod:: rfc3986.iri.IRIReference.authority_info
