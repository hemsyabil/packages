// SPDX-FileCopyrightText: 2022 The meson-python developers
//
// SPDX-License-Identifier: MIT

int sum(int a, int b) {
	return a + b;
}
