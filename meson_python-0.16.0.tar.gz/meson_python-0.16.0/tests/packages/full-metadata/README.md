<!--
SPDX-FileCopyrightText: 2021 The meson-python developers

SPDX-License-Identifier: MIT
-->

# full-metadata

An example package with all of the PEP 621 metadata!
