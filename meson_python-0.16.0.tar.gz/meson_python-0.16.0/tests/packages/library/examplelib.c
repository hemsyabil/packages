// SPDX-FileCopyrightText: 2021 The meson-python developers
//
// SPDX-License-Identifier: MIT

int sum(int a, int b) {
	return a + b;
}
