// SPDX-FileCopyrightText: 2021 The meson-python developers
//
// SPDX-License-Identifier: MIT

#include <stdio.h>

int sum(int, int);

int main() {
	printf("sum: %d", sum(1, 2));
}
