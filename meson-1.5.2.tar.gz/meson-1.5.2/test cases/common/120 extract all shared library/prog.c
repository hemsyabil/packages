#include"extractor.h"
#include<stdio.h>

int main(void) {
    if((1+2+3+4) != (func1() + func2() + func3() + func4())) {
        printf("Arithmetic is fail.\n");
        return 1;
    }
    return 0;
}
