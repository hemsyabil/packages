// cmMod.hpp (L)
#pragma once

#error "cmMod.hpp in incL must not be included"
