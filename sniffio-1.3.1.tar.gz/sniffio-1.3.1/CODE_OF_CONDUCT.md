For the Trio code of conduct, see:
    https://trio.readthedocs.io/en/latest/code-of-conduct.html
